import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Experience {
  position: string;
  company: string;
  period: string;
  description: string;
  achievements: string[];
  technologies: string[];
}

interface Education {
  degree: string;
  institution: string;
  period: string;
  gpa?: string;
  relevant?: string[];
}
@Component({
  selector: 'app-resume',
  imports: [CommonModule],
  templateUrl: './resume.component.html',
  styleUrl: './resume.component.scss'
})
export class ResumeComponent {
   yearsOfExperience = 2;

  skillCategories = [
    {
      name: 'Frontend',
      skills: ['React', 'Angular', 'TypeScript', 'JavaScript', 'HTML5', 'CSS3', 'SASS']
    },
    {
      name: 'Backend',
      skills: ['ASP.Core','Python','Flask', 'REST APIs',]
    },
    {
      name: 'Database',
      skills: [ 'PostgreSQL', 'MySQL', 'Firebase']
    },
    {
      name: 'DevOps & Tools',
      skills: ['Docker', 'Git']
    }
  ];

  experiences: Experience[] = [
    {
      position: 'Junior Full Stack Developer',
      company: 'Tech Solutions Inc.',
      period: '2022 - Present',
      description: 'Lead development of enterprise-level web applications serving 100K+ users daily. Mentor junior developers and architect scalable solutions.',
      achievements: [
        'Increased application performance by 40% through code optimization and caching strategies',
        'Led a team of 5 developers in migrating legacy systems to modern React architecture',
        'Implemented automated testing pipeline reducing bugs in production by 60%',
        'Designed and developed microservices architecture improving system scalability'
      ],
      technologies: ['React', 'Node.js', 'AWS', 'MongoDB', 'Docker', 'Kubernetes']
    },
    {
      position: 'Full Stack Developer',
      company: 'Digital Innovations LLC',
      period: '2020 - 2022',
      description: 'Developed and maintained multiple client projects ranging from e-commerce platforms to custom business applications.',
      achievements: [
        'Built 15+ responsive web applications with 99.9% uptime',
        'Integrated third-party APIs and payment gateways for e-commerce solutions',
        'Collaborated with UI/UX team to implement pixel-perfect designs',
        'Reduced page load times by 50% through optimization techniques'
      ],
      technologies: ['Angular', 'Python', 'PostgreSQL', 'AWS', 'Stripe API']
    },
    {
      position: 'Frontend Developer',
      company: 'StartupXYZ',
      period: '2019 - 2020',
      description: 'Focused on creating intuitive user interfaces and improving user experience for the company\'s main product.',
      achievements: [
        'Developed responsive web applications using modern JavaScript frameworks',
        'Implemented user authentication and authorization systems',
        'Collaborated with backend team to integrate RESTful APIs',
        'Improved user engagement by 30% through UI/UX enhancements'
      ],
      technologies: ['Vue.js', 'JavaScript', 'SCSS', 'REST APIs']
    }
  ];

  education: Education[] = [
    {
      degree: 'Bachelor of Science in Computer Science',
      institution: 'University of Technology',
      period: '2015 - 2019',
      gpa: '3.8/4.0',
      relevant: ['Data Structures', 'Algorithms', 'Database Systems', 'Web Development', 'Software Engineering']
    }
  ];

  certifications = [
    {
      icon: '☁️',
      title: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2023'
    },
    {
      icon: '⚛️',
      title: 'React Developer Certification',
      issuer: 'Meta',
      date: '2022'
    },
    {
      icon: '🏆',
      title: 'Google Cloud Professional Developer',
      issuer: 'Google Cloud',
      date: '2022'
    },
    {
      icon: '🎯',
      title: 'Scrum Master Certification',
      issuer: 'Scrum Alliance',
      date: '2021'
    }
  ];

  downloadResume(): void {
    // Implement PDF download functionality
    alert('PDF download would be implemented here');
  }

  printResume(): void {
    window.print();
  }

}
